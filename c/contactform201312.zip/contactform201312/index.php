<?php
/*
 * お問い合わせフォーム
*
* 株式会社i-on [イオン] i-on Co., Ltd.
* http://www.i-ongroup.com/
* 〒263-0032　千葉市稲毛区稲毛台町15-8
* Tel  ： 043-243-9729
* Fax  ： 043-246-5653
*/
// POSTされたデータを取得します。
$sei = isset($_POST["sei"])? $_POST["sei"] : "";
$mei = isset($_POST["mei"])? $_POST["mei"] : "";
$mail = isset($_POST["mail"])? $_POST["mail"] : "";
$naiyou = isset($_POST["naiyou"])? $_POST["naiyou"] : "";

// 画面表示
require_once("header.php");
?>
<body>
<div class="main">
<div id="contactInfo">

	<h1>お問い合わせ</h1>

	<form name="form1" action="./confirm.php" method="post">
	  
	  <p>
	  <span class="f_red">※</span>印は必須入力です。<br>
	  必要事項を入力し、「次へ」をクリックしてください。
	  </p>
	  
	  <table class="contact_tbl">
	    <tr>
	      <th>お名前</th>
	      <td>
	        姓<input type="text" id="sei" name="sei" value="<?php echo htmlspecialchars($sei, ENT_QUOTES, "UTF-8");?>">
	        &nbsp;&nbsp;
	        名<input type="text" id="mei" name="mei" value="<?php echo htmlspecialchars($mei, ENT_QUOTES, "UTF-8");?>">
	      </td>
	    </tr>
	    <tr>
	      <th><span class="f_red">※</span> E-mail</th>
	      <td>
	      	<input type="email" id="mail" name="mail" value="<?php echo htmlspecialchars($mail, ENT_QUOTES, "UTF-8");?>" required>
	      	<br>メールアドレスに間違いがあると回答を返信できませんので十分ご注意ください。
	      </td>
	    </tr>
	    <tr>
	      <th><span class="f_red">※</span> 内容</th>
	      <td><textarea id="naiyou" name="naiyou" required><?php echo htmlspecialchars($naiyou, ENT_QUOTES, "UTF-8");?></textarea></td>
	    </tr>
	  </table>
	  <div id="btn_area">
	  	<input type="submit" name="next_btn" value="次へ" class="btn">
	  </div>

	</form>
	  
</div><!--/contactInfo-->
</div><!--/main-->
</body>
</html>