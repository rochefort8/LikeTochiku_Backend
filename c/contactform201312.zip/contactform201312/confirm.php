<?php
/*
 * お問い合わせフォーム
 *
 * 株式会社i-on [イオン] i-on Co., Ltd.
 * http://www.i-ongroup.com/
 * 〒263-0032　千葉市稲毛区稲毛台町15-8
 * Tel  ： 043-243-9729
 * Fax  ： 043-246-5653
 */
// POSTされたデータを取得します。
$sei = isset($_POST["sei"])? $_POST["sei"] : "";
$mei = isset($_POST["mei"])? $_POST["mei"] : "";
$mail = isset($_POST["mail"])? $_POST["mail"] : "";
$naiyou = isset($_POST["naiyou"])? $_POST["naiyou"] : "";

// ----- 入力チェック -----
$err_msg = array();	// エラーメッセージを格納する配列

// (1)必須チェック
if(strlen($mail) == 0){
	$err_msg[] = "E-mailを入力してください。";
}
if(strlen($naiyou) == 0){
	$err_msg[] = "お問い合わせ内容を入力してください。";
}
// (2)フォーマットチェック
if(count($err_msg) == 0){
	if(!preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $mail)) {
		$err_msg[] = "正しいE-mailを入力してください。";
	}
}

// ----- 画面表示 -----
require_once("header.php");
?>
<body>
<div class="main">
<div id="contactInfo">

	<h1>お問い合わせ（確認）</h1>

	<?php if(count($err_msg) > 0){?>
	<div class="error">
		入力エラーがあります。<br>
		<ul>
			<?php foreach($err_msg as $msg){?>
				<li><?php echo $msg;?></li>
			<?php }?>
		</ul>
	</div>
	<?php }else{ ?>
		<p>
		この内容でよろしければ、「送信」をクリックしてください。
		<br>メールアドレスに間違いがあると回答を返信できませんので十分ご確認ください。
		</p>
	<?php }?>

	<form name="form1" action="./send.php" method="post">
	  <input type="hidden" name="sei" value="<?php echo htmlspecialchars($sei, ENT_QUOTES, "UTF-8");?>">
	  <input type="hidden" name="mei" value="<?php echo htmlspecialchars($mei, ENT_QUOTES, "UTF-8");?>">
	  <input type="hidden" name="mail" value="<?php echo htmlspecialchars($mail, ENT_QUOTES, "UTF-8");?>">
	  <input type="hidden" name="naiyou" value="<?php echo htmlspecialchars($naiyou, ENT_QUOTES, "UTF-8");?>">
	  <table  class="contact_tbl">
	    <tr>
	      <th>お名前</th>
	      <td>
	        <?php echo htmlspecialchars($sei, ENT_QUOTES, "UTF-8");?>
	        &nbsp;&nbsp;
	        <?php echo htmlspecialchars($mei, ENT_QUOTES, "UTF-8");?>
	      </td>
	    </tr>
	    <tr>
	      <th>E-mail</th>
	      <td><?php echo htmlspecialchars($mail, ENT_QUOTES, "UTF-8");?></td>
	    </tr>
	    <tr>
	      <th>内容</th>
	      <td><?php echo nl2br(htmlspecialchars($naiyou, ENT_QUOTES, "UTF-8"));?></td>
	    </tr>
	  </table>
	  <div id="btn_area">
		  <input type="button" name="back_btn" value="戻る"
		         onclick="form1.action='./index.php';form1.submit();" class="btn">
		  &nbsp;&nbsp;
		  <?php if(count($err_msg) == 0){?>
		  <input type="submit" name="next_btn" value="送信" class="btn">
		  <?php }?>
	  </div>
	</form>

</div><!--/contactInfo-->
</div><!--/main-->
</body>
</html>