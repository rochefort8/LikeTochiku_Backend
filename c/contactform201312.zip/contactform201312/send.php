<?php
/*
 * お問い合わせフォーム
*
* 株式会社i-on [イオン] i-on Co., Ltd.
* http://www.i-ongroup.com/
* 〒263-0032　千葉市稲毛区稲毛台町15-8
* Tel  ： 043-243-9729
* Fax  ： 043-246-5653
*/
// POSTされたデータを取得します。
$sei = isset($_POST["sei"])? $_POST["sei"] : "";
$mei = isset($_POST["mei"])? $_POST["mei"] : "";
$mail = isset($_POST["mail"])? $_POST["mail"] : "";
$naiyou = isset($_POST["naiyou"])? $_POST["naiyou"] : "";

// ----- メール送信 -----
$success_to_customer = false;
$success_to_admin = false;
$admin_mail = "★★★ここにご自分のメールアドレスを書いてください★★★";  // 管理者のメールアドレス

// 文字コード設定
mb_language("Japanese");
mb_internal_encoding("UTF-8");
// 本文作成
$body = "";
if(strlen($sei) > 0 || strlen($mei) > 0){// 入力があれば名前を表示
	$body .= $sei." ".$mei."　様\n\n";
}
$body .= "---------------------------------------------------------------------\n";
$body .= "本メールはお問い合わせの情報がサーバに到達した時点で送信される、\n自動配信メールです。\n";
$body .= "---------------------------------------------------------------------\n";
$body .= "\n";
$body .= "[E-mail]　".$mail."\n";
$body .= "[内容]\n";
$body .= $naiyou."\n";
$body .= "\n";
$body .= "---------------------------------------------------------------------\n";
$body .= "\n";
$body .= "後日担当者から、ご連絡を差し上げます。今しばらくお待ちくださいませ。\n";
$body .= "日程によりましては、お返事に時間がかかる場合がございます。\n";
$body .= "何卒ご了承ください。\n";
$body .= "\n";
$body .= "---------------------------------------------------------------------\n";

// 送信処理（ユーザ宛）
$to = $mail;
$header = "From: ".$admin_mail;
$subject = "Webサイトからお問い合わせを承りました。";
if(mb_send_mail($to, $subject, $body, $header)){
   $success_to_customer = true; // 送信成功
}
// 送信処理（管理者宛）
if($success_to_customer){
  $to = $admin_mail;
  $header = "From: ".$admin_mail;
  $subject = "【管理者へ転送】Webサイトからお問い合わせを承りました。";
  if(mb_send_mail($to, $subject, $body, $header)){
     $success_to_admin = true;  // 送信成功
  }
}

// ----- 画面表示 -----
require_once("header.php");
?>
<body>
<div class="main">
<div id="contactInfo">

<?php if($success_to_customer && $success_to_admin){ ?>
	<h1>お問い合わせ（完了）</h1>
	<div id="thanks">
		<p>
			お問い合わせを送信しました。<br>
			後日担当者から、ご連絡を差し上げます。今しばらくお待ちくださいませ。<br>
			<br>
			※日程によりましては、お返事に時間がかかる場合がございます。何卒ご了承くださいませ。
		</p>
	</div>
<?php } ?>

<?php if(!$success_to_customer || !$success_to_admin){ ?>
	<h1>お問い合わせ（送信失敗）</h1>
	<p>
		<span class="error">送信に失敗しました。</span>
	</p>
<?php } ?>

</div><!--/contactInfo-->
</div><!--/main-->
</body>
</html>