<?php 
/*
 * お問い合わせフォーム
 *
 * 株式会社i-on [イオン] i-on Co., Ltd.
 * http://www.i-ongroup.com/
 * 〒263-0032　千葉市稲毛区稲毛台町15-8
 * Tel  ： 043-243-9729
 * Fax  ： 043-246-5653
 */
?>
<!DOCTYPE html>
<html>
<head>
<meta charset = "UTF-8">
<title>お問い合わせ</title>
<link rel="stylesheet" href="./contact.css" type="text/css" />
</head>